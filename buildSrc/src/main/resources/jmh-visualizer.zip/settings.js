var defaultSettings = { // eslint-disable-line no-unused-vars
    topBar: 'Result Library Benchmark Report'
}